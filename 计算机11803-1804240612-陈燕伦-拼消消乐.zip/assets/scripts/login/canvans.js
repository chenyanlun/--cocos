

cc.Class({
    extends: cc.Component,

    properties: {
        startButton:cc.Node,
        startButton2:cc.Node
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
       let action = cc.repeatForever(
           cc.sequence(
               cc.rotateBy(0.3,4),
               cc.rotateBy(0.6,-8),
               cc.rotateBy(0.3,4),
               cc.delayTime(0.5)
           )
       );
       let action1 = cc.repeatForever(
        cc.sequence(
            cc.rotateBy(0.3,4),
            cc.rotateBy(0.6,-8),
            cc.rotateBy(0.3,4),
            cc.delayTime(0.5)
        )
    );
       this.startButton.runAction(action);
       this.startButton2.runAction(action1);
       
       
       
    },

    // update (dt) {},

    toMainScence(){
        cc.director.loadScene('main');
    },

    toTextScence(){
        cc.director.loadScene('text');
    }
});
