
cc.Class({
    extends: cc.Component,

    properties: {
        hit:{
            type:cc.AudioClip,
            default:null
        },

        over:{
            type:cc.AudioClip,
            default:null
        },
        
        combo:{
            type:[cc.AudioClip],
            default:[]
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    // update (dt) {},
    /**
     * @param {number} id
     */
    playCombo(id){
       if(id<0)  return;
       if(id>5){
           id=5;
       }
       cc.audioEngine.playEffect(this.combo[id],false);
    },

    playHit(){
        cc.audioEngine.playEffect(this.hit,false);
    },

    playOver(){
        cc.audioEngine.playEffect(this.over,false);
    },
});
