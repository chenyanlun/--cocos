"use strict";
cc._RF.push(module, '8b38doMrqJC3a9guVCYfZe2', 'music');
// scripts/login/music.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        bgm: {
            type: cc.AudioClip,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        if (!cc.audioEngine.isMusicPlaying()) {
            cc.audioEngine.playMusic(this.bgm, true);
        }
    }
}

// update (dt) {},
);

cc._RF.pop();