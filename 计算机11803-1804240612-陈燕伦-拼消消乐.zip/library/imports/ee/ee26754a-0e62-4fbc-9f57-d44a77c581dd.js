"use strict";
cc._RF.push(module, 'ee267VKDmJPvJ9X1Ep3xYHd', 'main-music');
// scripts/main/main-music.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        hit: {
            type: cc.AudioClip,
            default: null
        },

        over: {
            type: cc.AudioClip,
            default: null
        },

        combo: {
            type: [cc.AudioClip],
            default: []
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    // update (dt) {},
    /**
     * @param {number} id
     */
    playCombo: function playCombo(id) {
        if (id < 0) return;
        if (id > 5) {
            id = 5;
        }
        cc.audioEngine.playEffect(this.combo[id], false);
    },
    playHit: function playHit() {
        cc.audioEngine.playEffect(this.hit, false);
    },
    playOver: function playOver() {
        cc.audioEngine.playEffect(this.over, false);
    }
});

cc._RF.pop();