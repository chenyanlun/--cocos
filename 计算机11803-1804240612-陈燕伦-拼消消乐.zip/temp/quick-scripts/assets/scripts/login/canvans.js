(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/login/canvans.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2b80eMnvchJRpeix8ZJEDzM', 'canvans', __filename);
// scripts/login/canvans.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        startButton: cc.Node,
        startButton2: cc.Node
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        var action = cc.repeatForever(cc.sequence(cc.rotateBy(0.3, 4), cc.rotateBy(0.6, -8), cc.rotateBy(0.3, 4), cc.delayTime(0.5)));
        var action1 = cc.repeatForever(cc.sequence(cc.rotateBy(0.3, 4), cc.rotateBy(0.6, -8), cc.rotateBy(0.3, 4), cc.delayTime(0.5)));
        this.startButton.runAction(action);
        this.startButton2.runAction(action1);
    },


    // update (dt) {},

    toMainScence: function toMainScence() {
        cc.director.loadScene('main');
    },
    toTextScence: function toTextScence() {
        cc.director.loadScene('text');
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=canvans.js.map
        