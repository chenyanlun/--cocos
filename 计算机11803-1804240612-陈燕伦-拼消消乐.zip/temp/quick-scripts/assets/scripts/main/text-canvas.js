(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/main/text-canvas.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e84172eittGq5DFaiWJynmw', 'text-canvas', __filename);
// scripts/main/text-canvas.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: function properties() {
        return {
            blockManager: require('text-blockManager'),
            musicRoot: require('main-music'),
            //hpManager:cc.Node,
            time: cc.Label,
            showScoreLable: cc.Label
        };
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        //this.hp=5;
        this.score = 0;
    },
    start: function start() {
        this.openTouch();
        //this.updateHpShow(this.hp);
        this.time.string = 60;
        this.schedule(this.doCountdownTime, 1);
    },


    // update (dt) {},
    touchEnd: function touchEnd(e) {
        this.musicRoot.playHit();
        //获取下位置
        var pos = this.node.convertToNodeSpaceAR(e.getLocation());
        //该区域空间为130*130，所以5个方块连成一排就是650
        //即坐标转化为325 col为行 row为列
        //后面+1是5*5的空间而我采用的是7*7的二维数组
        var col = Math.floor((325 + pos.x) / 130) + 1;
        var row = Math.floor((325 - pos.y) / 130) + 1;
        console.log(col, row);

        if (col < 1 || col > 5 || row < 1 || row > 5) {
            console.log('出界');
            return;
        }
        if (!this.blockManager.blockAddOne(col, row)) {
            return;
        }
        /*if(this.time.string<0){
            console.log('game over');
            this.musicRoot.playOver();
            this.scheduleOnce(()=>{
                cc.director.loadScene('login');
            },1);
        }*/
        //this.hp-=1;
        //this.updateHpShow(this.hp);
        this.closeTouch();
        //每次检测前都归零于BOOK，count也是0
        this.blockManager.count = 0;
        this.blockManager.setZeroBook();
        var num = this.blockManager.map[col][row];
        this.blockManager.mapForCount(col, row, num);
        if (this.blockManager.count < 3) {
            this.openTouch();
            return;
        }
        this.blockManager.hits = 0;
        //this.updateScoreLabel(this.blockManager.count,this.blockManager.map[col][row]);
        this.blockManager.doActionForBook(col, row);
    },
    doCountdownTime: function doCountdownTime() {
        //每秒显示更新信息
        if (this.time.string > 0) {
            this.time.string -= 1;
            this.countDownShow(this.time.string);
        }
    },
    countDownShow: function countDownShow(temp) {
        if (temp <= 0) {
            this.time.string = 0;
            //倒计时结束
            this.unschedule(this.doCountdownTime);
            console.log('game over!');
            this.musicRoot.playOver();
            this.scheduleOnce(function () {
                cc.director.loadScene('login');
            }, 1);
            //执行其他操作
        }
    },

    /*updateHpShow(hp){
        if(hp<0) hp=0;
        if(hp>5) hp=5;
        for(let i=0;i<5;i++){
            this.hpManager.children[i].opacity=0;
        }
        for(let i=0;i<hp;i++){
            this.hpManager.children[i].opacity=255;
        }
      },*/

    //分数增加，传入消除的数量和消除方块的数
    updateScoreLabel: function updateScoreLabel(num, k) {
        var _this = this;

        this.showScoreLable.node.runAction(cc.sequence(cc.scaleTo(0.1, 1.2), cc.callFunc(function () {
            _this.score += (k + 1) * num;
            _this.showScoreLable.string = _this.score + "";
        }, this), cc.scaleTo(0.1, 1)));
    },
    openTouch: function openTouch() {
        this.node.on(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
    },
    closeTouch: function closeTouch() {
        this.node.off(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=text-canvas.js.map
        